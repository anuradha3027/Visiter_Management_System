import { useState } from 'react'
import './App.css'
import Login from './Login'
import Insert from './Insert'
import Select from './Select'
import Home from './Home'
import Card from './Cardd'
function App() {

  return (
    <>
    <Login/>
    {/* <Select/> */}
    {/* <Home/> */}
    {/* <Card/> */}
    </>
  )
}

export default App
